/**
 * Clase que representa el pago con tarjeta de crédito.
 * Implementa la interfaz Payment.
 */
public class CreditCardPayment implements Payment {
    /**
     * Procesa el pago usando tarjeta de crédito.
     *
     * @param amount el monto a procesar
     */
    @Override
    public void processPayment(double amount) {
        System.out.println("Procesando pago con tarjeta de crédito por el monto de: " + amount);
    }
}
