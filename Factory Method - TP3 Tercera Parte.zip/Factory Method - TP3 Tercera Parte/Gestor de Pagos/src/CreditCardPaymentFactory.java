/**
 * Fábrica concreta para crear instancias de CreditCardPayment.
 * Extiende la clase abstracta PaymentFactory.
 */
public class CreditCardPaymentFactory extends PaymentFactory {
    /**
     * Crea y devuelve una instancia de CreditCardPayment.
     *
     * @return una instancia de CreditCardPayment
     */
    @Override
    public Payment createPaymentMethod() {
        return new CreditCardPayment();
    }
}
