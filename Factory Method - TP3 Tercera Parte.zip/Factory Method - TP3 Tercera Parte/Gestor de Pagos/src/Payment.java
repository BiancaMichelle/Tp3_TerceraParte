/**
 * Interfaz que representa un método de pago.
 */
public interface Payment {
    /**
     * Procesa el pago por el monto especificado.
     *
     * @param amount el monto a procesar
     */
    void processPayment(double amount);
}
