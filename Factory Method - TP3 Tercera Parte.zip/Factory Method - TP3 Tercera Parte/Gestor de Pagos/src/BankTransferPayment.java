/**
 * Clase que representa el pago mediante transferencia bancaria.
 * Implementa la interfaz Payment.
 */
public class BankTransferPayment implements Payment {
    /**
     * Procesa el pago usando transferencia bancaria.
     *
     * @param amount el monto a procesar
     */
    @Override
    public void processPayment(double amount) {
        System.out.println("Procesando pago con transferencia bancaria por el monto de: " + amount);
    }
}
