/**
 * Clase que representa el pago con PayPal.
 * Implementa la interfaz Payment.
 */
public class PayPalPayment implements Payment {
    /**
     * Procesa el pago usando PayPal.
     *
     * @param amount el monto a procesar
     */
    @Override
    public void processPayment(double amount) {
        System.out.println("Procesando pago con PayPal por el monto de: " + amount);
    }
}
