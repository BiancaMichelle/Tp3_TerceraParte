/**
 * Clase abstracta que define un método de fábrica para crear métodos de pago.
 * Utiliza el patrón Factory Method.
 */
public abstract class PaymentFactory {
    /**
     * Método de fábrica para crear un método de pago.
     *
     * @return una instancia de Payment
     */
    public abstract Payment createPaymentMethod();
}
