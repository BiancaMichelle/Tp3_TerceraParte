/**
 * Fábrica concreta para crear instancias de PayPalPayment.
 * Extiende la clase abstracta PaymentFactory.
 */
public class PayPalPaymentFactory extends PaymentFactory {
    /**
     * Crea y devuelve una instancia de PayPalPayment.
     *
     * @return una instancia de PayPalPayment
     */
    @Override
    public Payment createPaymentMethod() {
        return new PayPalPayment();
    }
}
