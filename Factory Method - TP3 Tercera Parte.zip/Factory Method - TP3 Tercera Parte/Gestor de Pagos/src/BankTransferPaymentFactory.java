/**
 * Fábrica concreta para crear instancias de BankTransferPayment.
 * Extiende la clase abstracta PaymentFactory.
 */
public class BankTransferPaymentFactory extends PaymentFactory {
    /**
     * Crea y devuelve una instancia de BankTransferPayment.
     *
     * @return una instancia de BankTransferPayment
     */
    @Override
    public Payment createPaymentMethod() {
        return new BankTransferPayment();
    }
}
