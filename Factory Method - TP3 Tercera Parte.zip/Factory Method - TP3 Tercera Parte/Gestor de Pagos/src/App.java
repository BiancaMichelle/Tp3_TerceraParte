/**
 * Clase principal para probar el sistema de gestión de pagos.
 */
public class App {
    /**
     * Método principal que ejecuta la prueba del sistema.
     *
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        // Crear las fábricas de métodos de pago
        PaymentFactory creditCardFactory = new CreditCardPaymentFactory();
        PaymentFactory paypalFactory = new PayPalPaymentFactory();
        PaymentFactory bankTransferFactory = new BankTransferPaymentFactory();

        // Procesar pagos utilizando las fábricas
        Payment creditCardPayment = creditCardFactory.createPaymentMethod();
        creditCardPayment.processPayment(100.00);

        Payment paypalPayment = paypalFactory.createPaymentMethod();
        paypalPayment.processPayment(200.00);

        Payment bankTransferPayment = bankTransferFactory.createPaymentMethod();
        bankTransferPayment.processPayment(300.00);
    }
}
